create database airport;
use airport;

create table planes(
contactno varchar(30),
email varchar(30),
ownerFirstName varchar(30),
ownerLastName varchar(30),
ownerid int,
planeCapacity int,
planeType varchar(30),
planestatus varchar(30),
planeid int primary key 
);

create table Hangar(
hangarId int primary key,
managerId varchar(30),
addressLine1 varchar(100),
addressLine2 varchar(100),
city varchar(20),
state varchar(30),
zipCode varchar(10),
hangarstatus varchar(30)
);


create table pilots(
licenseNumber varchar(30),
addressLine1 varchar(30),
addressLine2 varchar(30),
city varchar(30),
state varchar(30),
zipcode varchar(30),
ssn varchar(9),
pilotid int primary key 
);


create table HangarStatus(
id int PRIMARY KEY,
hangarId int,
planeid int,
status varchar(20),
occFromDate  varchar(20),
occTillDate  varchar(20),
avlFromDate  varchar(20),
avlTillDate  varchar(20)
);


create table ManagerRegister(
managerId varchar(20) primary key,
status int(2),
firstName varchar(50),
lastName varchar(50),
age int(2),
gender varchar(7),
dob varchar(10),
contactNo varchar(10),
altContactNo varchar(10),
emailId varchar(50),
password varchar(15)
);


select * from PLANES;
select * from Hangar;
select * from  HangarStatus;
select * from PILOTS;