package com.pack;

import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.form.Pilots;
import com.pack.service.PilotsService;

@Controller
public class PilotsController {
	private static Logger log = Logger.getLogger(PilotsController.class);

	private PilotsService pilotsService;

	@Autowired(required = true)
	@Qualifier(value = "pilotsService")
	public void setPilotsService(PilotsService pilotsService) {
		this.pilotsService = pilotsService;
	}

	@RequestMapping(value = "/index7")
	public String listPilots(Map<String, Object> map, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("pilots", new Pilots());
			return "AddPilots";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/pilots/add", method = RequestMethod.POST)
	public String addPilots(@ModelAttribute("pilots") @Validated Pilots pilots, BindingResult bindingResult,
			Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			if (bindingResult.hasErrors()) {
				log.info("validation error");
				return "AddPilots";
			} else if (null == pilots.getPilotid()) {
				Random rand = new Random();
				int num = rand.nextInt(900000) + 1000000;
				pilots.setPilotid(num);

				log.info("Before add pilots");
				pilotsService.addPilots(pilots);
			}

			return "AddResult";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/index8")

	public String UpdatePilots(Map<String, Object> map, Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {

			map.put("pilots", new Pilots());
			model.addAttribute("pilotsList", pilotsService.listPilots());
			return "UpdatePilots";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/pilots/updatepilot", method = RequestMethod.POST)
	public String updatePilots(@ModelAttribute("pilots") @Validated Pilots pilots, BindingResult bindingResult,
			Model model) {
		pilotsService.updatePilots(pilots);
		model.addAttribute("pilotsList", pilotsService.listPilots());
		return "UpdateResult";
	}

	@RequestMapping("/updatepilot/{pilotid}")
	public String updatePilot(@PathVariable("pilotid") Integer pid, Map<String, Object> map) {
		map.put("pilots", pilotsService.getPilotsById(pid));
		log.info("Getting details for pilots ID" + pid);
		map.put("pilotsList", pilotsService.listPilots());
		log.info("Retrieving Pilots information");
		return "UpdatePilots";
	}

	@RequestMapping(value = "/index9")
	public String ViewPilots(Map<String, Object> map, Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("pilots", new Pilots());
			model.addAttribute("pilotsList", pilotsService.listPilots());
			return "ViewPilots";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping("/view/{pilotid}")
	public String viewPilot(@PathVariable("pilotid") Integer pid, Map<String, Object> map) {
		map.put("pilots", pilotsService.getPilotsById(pid));
		log.info("Getting details for pilots ID" + pid);
		return "ViewDetails";
	}
}
