package com.pack;

import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.form.Planes;
import com.pack.service.PlanesService;

@Controller
public class PlanesController {
	private static Logger log = Logger.getLogger(PlanesController.class);

	private PlanesService planesService;

	@Autowired(required = true)
	@Qualifier(value = "planesService")
	public void setPlanesService(PlanesService planesService) {
		this.planesService = planesService;
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String Planes(HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			return "successAdmin";
		} else {
			return "welcomepage";
		}

	}

	@RequestMapping(value = "/index1")
	public String listPlanes(Map<String, Object> map, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("planes", new Planes());
			return "AddPlanes";
		} else
			return "welcomepage";
	}

	@RequestMapping(value = "/planes/add", method = RequestMethod.POST)
	public String addPlanes(@ModelAttribute("planes") @Validated Planes planes, BindingResult bindingResult,
			Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			if (bindingResult.hasErrors()) {
				log.info("validation error");
				return "AddPlanes";
			}

			else {
				if (null == planes.getPlaneid()) {
					Random rand = new Random();
					int num = rand.nextInt(900000) + 1000000;
					planes.setPlaneid(num);
				}
				if (null == planes.getOwnerid()) {
					Random rand = new Random();
					int num = rand.nextInt(900000) + 1000000;
					planes.setOwnerid(num);
				}
				log.info("Before add planes");
				planesService.addPlanes(planes);
			}

			return "AddResult";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/index2")

	public String UpdatePlanes(Map<String, Object> map, Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("planes", new Planes());
			model.addAttribute("planesList", planesService.listPlanes());
			return "UpdatePlanes";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/planes/update", method = RequestMethod.POST)
	public String updatePlanes(@ModelAttribute("planes") @Validated Planes planes, BindingResult bindingResult,
			Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			planesService.updatePlanes(planes);
			model.addAttribute("planesList", planesService.listPlanes());
			return "UpdateResult";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping("/update/{planeid}")
	public String updatePlane(@PathVariable("planeid") Integer pid, Map<String, Object> map, HttpSession session) {
		if ((session.getAttribute("username")) != null) {

			map.put("planes", planesService.getPlanesById(pid));
			log.info("Getting details for planes ID" + pid);
			map.put("planesList", planesService.listPlanes());
			log.info("Retrieving Planes information");
			return "UpdatePlanes";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/index3")
	public String ViewPlanes(Map<String, Object> map, Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("planes", new Planes());
			model.addAttribute("planesList", planesService.listPlanes());
			return "ViewPlanes";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping("/viewplanes/{planeid}")
	public String viewPlane(@PathVariable("planeid") Integer pid, Map<String, Object> map, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("planes", planesService.getPlanesById(pid));
			log.info("Getting details for planes ID" + pid);

			log.info("Retrieving Planes information");
			return "ViewPlaneDetail";
		} else {
			return "welcomepage";
		}
	}
}
