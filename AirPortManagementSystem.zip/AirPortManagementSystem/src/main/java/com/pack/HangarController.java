package com.pack;

import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.form.Hangar;
import com.pack.service.HangarService;

@Controller
public class HangarController {
	private static Logger log = Logger.getLogger(HangarController.class);
	private HangarService hangarService;

	@Autowired(required = true)
	@Qualifier(value = "hangarService")
	public void setHangerService(HangarService hangarService) {
		this.hangarService = hangarService;
	}

	@RequestMapping(value = "/index4")
	public String listHangar(Map<String, Object> map, HttpSession session) {

		if ((session.getAttribute("username")) != null) {
			map.put("hangar", new Hangar());
			return "AddHangar";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/hangar/add", method = RequestMethod.POST)
	public String addHangar(@ModelAttribute("hangar") @Validated Hangar hangar, BindingResult bindingResult,
			Model model, HttpSession session) {

		if ((session.getAttribute("username")) != null) {
			if (bindingResult.hasErrors()) {
				log.info("validation error");
				return "AddHangar";
			} else if (null == hangar.getHangarId()) {
				Random rand = new Random();
				int num = rand.nextInt(900000) + 1000000;
				hangar.setHangarId(num);
				;

				log.info("Before add Hangar");
				hangarService.addHangar(hangar);
			}

			return "AddResult";
		} else
			return "welcomepage";
	}

	@RequestMapping(value = "/index5")
	public String UpdateHangar(Map<String, Object> map, Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("hangar", new Hangar());
			model.addAttribute("hangarList", hangarService.listHangar());
			return "UpdateHangar";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/hangar/updatehangar", method = RequestMethod.POST)
	public String update(@ModelAttribute("hangar") @Validated Hangar hangar, BindingResult bindingResult, Model model) {
		log.info("Before hangar update");
		hangarService.updateHangar(hangar);
		log.info("After hangar update");
		model.addAttribute("hangarList", hangarService.listHangar());
		return "UpdateResult";
	}

	@RequestMapping("/updatehangar/{hangarId}")
	public String updateHangars(@PathVariable("hangarId") Integer hid, Map<String, Object> map) {
		map.put("hangar", hangarService.getHangarById(hid));
		log.info("Getting details for hangar ID" + hid);
		map.put("hangarList", hangarService.listHangar());
		log.info("Retrieving Hangar information");
		return "UpdateHangar";
	}

	@RequestMapping(value = "/index6")
	public String ViewHangar(Map<String, Object> map, Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("hangar", new Hangar());
			model.addAttribute("hangarList", hangarService.listHangar());
			return "ViewHangar";
		}

		else {
			return "welcomepage";
		}
	}

	@RequestMapping("/viewhangar/{hangarId}")
	public String viewHangars(@PathVariable("hangarId") Integer hid, Map<String, Object> map, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			map.put("hangar", hangarService.getHangarById(hid));
			log.info("Retrieving Hangar information");
			return "ViewHangarDetail";
		} else {
			return "welcomepage";
		}
	}
}
