package com.pack.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;


import com.pack.form.Planes;
import com.pack.service.PlanesServiceImpl;


@Repository
public class PlanesDaoImpl implements PlanesDao{

	 private SessionFactory sessionFactory;
     

     public void setSessionFactory(SessionFactory sessionFactory) {
            this.sessionFactory = sessionFactory;
     }

     private static Logger log=Logger.getLogger(PlanesServiceImpl.class);
     
     public void addPlanes(Planes p) {
            log.info("inside dao add planes");
            String planestatus="Available";
            p.setPlanestatus(planestatus);
            sessionFactory.getCurrentSession().save(p);
      }
     
     @Override
     public void updatePlanes(Planes p) {
            sessionFactory.getCurrentSession().update(p);
     }
     
     public List<Planes> listPlanes()
     {
  	   log.info("inside list ");
  	   Query q=sessionFactory.getCurrentSession().createQuery("from Planes");
  	   List l=q.list();
  	   return l;
     }
     
     public Planes getPlanesById(Integer pid)
     {
    	
  	   Query q=sessionFactory.getCurrentSession().createQuery("from Planes p where p.planeid=:planeid");
  	   q.setParameter("planeid", pid);
  	   Planes p=(Planes)q.uniqueResult();
  	   return p;
     }
}
