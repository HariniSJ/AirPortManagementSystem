package com.pack.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.pack.form.Hangar;
import com.pack.service.HangarStatusServiceImpl;


@Repository
public class HangarDaoImpl implements HangarDao {
 private SessionFactory sessionFactory;
    
     public void setSessionFactory(SessionFactory sessionFactory) {
            this.sessionFactory = sessionFactory;
     }

     private static Logger log=Logger.getLogger(HangarStatusServiceImpl.class);
     
     public void addHangar(Hangar h) {
            log.info("inside dao add hangar");
            String hangarstatus="Available";
            h.setHangarstatus(hangarstatus);
            sessionFactory.getCurrentSession().save(h);
      }
     
     @Override
     public void updateHangar(Hangar h) {
    	 log.info("inside dao update hangar");
    	 System.out.println(h.getHangarstatus());
    	 System.out.println(h.getHangarId());
         sessionFactory.getCurrentSession().update(h);
       log.info("outside dao update hangar");
     }
     
     public List<Hangar> listHangar()
     {
  	   log.info("inside list ");
  	   Query q=sessionFactory.getCurrentSession().createQuery("from Hangar");
  	   List l=q.list();
  	   return l;
     }
     
     public Hangar getHangarById(Integer hid)
     {
  	   Query q=sessionFactory.getCurrentSession().createQuery("from Hangar h where h.hangarId=:hangarId");
  	   q.setParameter("hangarId", hid);
  	   Hangar h=(Hangar)q.uniqueResult();
  	   return h;
     }
}
