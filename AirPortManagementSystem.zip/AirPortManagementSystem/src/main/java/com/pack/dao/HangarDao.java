package com.pack.dao;

import java.util.List;

import com.pack.form.Hangar;

public interface HangarDao {
	public void addHangar(Hangar h);

	public void updateHangar(Hangar h);

	public List<Hangar> listHangar();

	public Hangar getHangarById(Integer hid);
}
