package com.pack.dao;

import java.util.List;

import com.pack.form.Pilots;

public interface PilotsDao {
	public void addPilots(Pilots p);

	public void updatePilots(Pilots p);

	public List<Pilots> listPilots();

	public Pilots getPilotsById(Integer pid);
}
