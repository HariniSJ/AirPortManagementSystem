package com.pack.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;


import com.pack.form.Pilots;
import com.pack.service.PilotsServiceImpl;


@Repository
public class PilotsDaoImpl implements PilotsDao{

	 private SessionFactory sessionFactory;
     

     public void setSessionFactory(SessionFactory sessionFactory) {
            this.sessionFactory = sessionFactory;
     }

     private static Logger log=Logger.getLogger(PilotsServiceImpl.class);
     
     public void addPilots(Pilots p) {
            log.info("inside dao add pilots");
            sessionFactory.getCurrentSession().save(p);
            
     }
     
     @Override
     public void updatePilots(Pilots p) {
            sessionFactory.getCurrentSession().update(p);
     }
     
     public List<Pilots> listPilots()
     {
  	   log.info("inside list ");
  	   Query q=sessionFactory.getCurrentSession().createQuery("from Pilots");
  	   List l=q.list();
  	   return l;
     }
     
     public Pilots getPilotsById(Integer pid)
     {
  	   Query q=sessionFactory.getCurrentSession().createQuery("from Pilots p where p.pilotid=:pilotid");
  	   q.setParameter("pilotid", pid);
  	   Pilots p=(Pilots)q.uniqueResult();
  	   return p;
     }
}

