package com.pack.dao;

import java.util.List;

import com.pack.form.Planes;

public interface PlanesDao {
	public void addPlanes(Planes p);

	public void updatePlanes(Planes p);

	public List<Planes> listPlanes();

	public Planes getPlanesById(Integer pid);
}
