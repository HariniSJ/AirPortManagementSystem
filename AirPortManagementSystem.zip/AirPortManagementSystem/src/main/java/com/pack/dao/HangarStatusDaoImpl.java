package com.pack.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;

import com.pack.form.Hangar;
import com.pack.form.HangarStatus;
import com.pack.form.Planes;

public class HangarStatusDaoImpl implements HangarStatusDao {

	Logger log = Logger.getLogger(HangarStatusDaoImpl.class);

	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Hangar> fetchHangars() {
		log.info("Inside dao fetchHangars");
		Query q = sessionFactory.getCurrentSession().createQuery("from Hangar as h where h.hangarstatus = :status");
		q.setParameter("status", "Available");
		List l = q.list();
		System.out.println(l.size());
		return l;
	}

	@Override
	public List<HangarStatus> fetchHangarStatus() {
		log.info("Inside dao fetchHangarstatus");

		Query q = sessionFactory.getCurrentSession().createQuery("from HangarStatus as hs where hs.status=:status");
		q.setParameter("status", "Occupied");
		List l = q.list();
		return l;
	}

	@Override
	public List<Planes> fetchPlanes() {

		log.info("Inside dao fetchPlanes");
		Query q = sessionFactory.getCurrentSession().createQuery("from Planes as p where p.planestatus = :status");
		q.setParameter("status", "Available");
		List l = q.list();
		System.out.println(l.size());
		return l;
	}

	@Override
	public List<HangarStatus> getAllotedHangars() {

		log.info("Inside dao getAllotedHangars");
		Query q = sessionFactory.getCurrentSession().createQuery("from Hangar");
		List l = q.list();
		return l;
	}

	@Override
	public void updateHangars(HangarStatus hangarstatus) {
		log.info("Inside dao updateHangars");
		String status = "Occupied";
		hangarstatus.setStatus(status);
		sessionFactory.getCurrentSession().save(hangarstatus);
	}

	@Override
	public int updateHangarStatus(int hId) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("update Hangar as h set h.hangarstatus = :a where h.hangarId = :b");
		query.setParameter("a", "Occupied");
		query.setParameter("b", hId);
		int i = query.executeUpdate();
		return i;
	}

	@Override
	public int unassignHangarStatus(int hId) {
		Query query = sessionFactory.getCurrentSession().createQuery("update Hangar as h set h.hangarstatus = :a where h.hangarId = :b");
		query.setParameter("a", "Available");
		query.setParameter("b", hId);
		int i = query.executeUpdate();
		return i;
	}

	@Override
	public void unassignHangars(HangarStatus hangarStatus) {
		// TODO Auto-generated method stub
		log.info("Inside dao unassignHangar");

		Query query = sessionFactory.getCurrentSession().createQuery(
				"update HangarStatus as hs set hs.status = :o,hs.occFromDate=:a,hs.occTillDate=:b,hs.avlFromDate=:c,hs.avlTillDate=:d where hs.hangarId = :e");

		query.setParameter("o", "Available");

		String occupiedFromDate = hangarStatus.getOccFromDate();
		query.setParameter("a", occupiedFromDate);

		String occupiedTillDate = hangarStatus.getOccTillDate();
		query.setParameter("b", occupiedTillDate);

		String avaliableFromDate = hangarStatus.getAvlFromDate();
		query.setParameter("c", avaliableFromDate);

		String avaliableTillDate = hangarStatus.getAvlTillDate();
		query.setParameter("d", avaliableTillDate);

		Integer id = hangarStatus.getHangarId();

		query.setParameter("e", id);

		Integer pid = hangarStatus.getPlaneid();

		query.executeUpdate();
		log.info("Outside dao unassignHangar");

	}

	@Override
	public int updatePlaneStatus(int pId) {
		Query query = sessionFactory.getCurrentSession().createQuery("update Planes as p set p.planestatus = :a where p.planeid = :b");
		query.setParameter("a", "Occupied");
		query.setParameter("b", pId);
		int i = query.executeUpdate();
		return i;
	}

	@Override
	public int unassignPlaneStatus(int pId) {

		Query query = sessionFactory.getCurrentSession().createQuery("update Planes as p set p.planestatus = :a where p.planeid = :b");
		query.setParameter("a", "Available");
		query.setParameter("b", pId);
		int i = query.executeUpdate();
		return i;
	}

	@Override
	public HangarStatus getHangarStatusById(int id) {
		log.info("inside getHangarStatusById");
		Query q = sessionFactory.getCurrentSession().createQuery("from HangarStatus hs where hs.id=:id");
		q.setParameter("id", id);
		HangarStatus hs = (HangarStatus) q.uniqueResult();
		return hs;
	}
}
