package com.pack.dao;

import java.util.List;

import com.pack.form.Hangar;
import com.pack.form.HangarStatus;
import com.pack.form.Planes;

public interface HangarStatusDao {
	public List<Hangar> fetchHangars();

	public List<Planes> fetchPlanes();

	public List<HangarStatus> getAllotedHangars();

	public void updateHangars(HangarStatus hangarStatus);

	public void unassignHangars(HangarStatus hangarStatus);

	public int updateHangarStatus(int hId);

	public int unassignHangarStatus(int hId);

	public int updatePlaneStatus(int pId);

	public int unassignPlaneStatus(int pId);

	public List<HangarStatus> fetchHangarStatus();

	public HangarStatus getHangarStatusById(int id);
}
