package com.pack.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.pack.form.RegisterManager;
@Repository
public class AirportDaoImpl implements AirportDao{
	
	
	private SessionFactory sessionFactory;
	private AirportDaoImpl() { }
	 
   
    public void setSessionFactory(SessionFactory sessionFactory) {
    this.sessionFactory = sessionFactory;
    }

	public void addManager(RegisterManager m) 
	{
	       sessionFactory.getCurrentSession().save(m);
	}

	public Boolean validateManager(String managerId, String password) {
		Integer status=1;
		
		 Boolean isValidUser;
		 Query q=sessionFactory.getCurrentSession().createQuery("from RegisterManager r where r.managerId=:manager and r.password=:pass");
		 Query q1=sessionFactory.getCurrentSession().createQuery("select r.status from RegisterManager r where r.managerId=:manager and r.password=:pass");
		 q.setParameter("manager", managerId);
		 q.setParameter("pass", password);
		 q1.setParameter("manager", managerId);
		 q1.setParameter("pass", password);
		 List l=q.list();
		 List l1=q1.list();
		
		 if(l.size()>0 && l1.contains(status))
		 {
			 isValidUser=true;
		     return isValidUser;
		 }
		 else
		 {
			 isValidUser=false;
			 return isValidUser;
		 }
	}

	public List<RegisterManager> listManager() {
		Integer status=0;
        Query q=sessionFactory.getCurrentSession().createQuery("from RegisterManager r where r.status=:status");
        q.setParameter("status", status);
        List l=q.list();
        return l;
 }

	public void updateManager(String managerId,Integer status) {
		 Query q=sessionFactory.getCurrentSession().createQuery("update RegisterManager r set r.status = :newStatus where r.managerId = :managerId");
		 q.setParameter("managerId", managerId);
		 q.setParameter("newStatus", status);
		 q.executeUpdate();
	 }

	public void deleteManager(String managerId) {
		RegisterManager r=(RegisterManager)sessionFactory.getCurrentSession().get(RegisterManager.class, managerId);
        if(r!=null)
               sessionFactory.getCurrentSession().delete(r);
	}

	public String getManagerName(String managerId)
		{
			Query q=sessionFactory.getCurrentSession().createQuery("select firstName from RegisterManager r where r.managerId=:id");
			q.setParameter("id",managerId);
			List l=q.list();
			String name=(String) l.get(0);
			return name;
		}
}


