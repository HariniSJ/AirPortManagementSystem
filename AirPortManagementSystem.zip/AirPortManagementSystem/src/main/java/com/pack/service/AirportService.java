package com.pack.service;

import java.util.List;

import com.pack.form.RegisterManager;

public interface AirportService {
	public void addManager(RegisterManager m);

	public Boolean validateManager(String managerId, String password);

	public List<RegisterManager> listManager();

	public void updateManager(String managerId, Integer status);

	public void deleteManager(String managerId);

	public String getManagerName(String managerId);
}
