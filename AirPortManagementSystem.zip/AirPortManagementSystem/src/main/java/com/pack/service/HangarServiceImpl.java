package com.pack.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.dao.HangarDao;
import com.pack.form.Hangar;



@Service
public class HangarServiceImpl implements HangarService{
private HangarDao hangarDao;

public void setHangarDao(HangarDao hangarDao) {
	this.hangarDao = hangarDao;
}

private static Logger log=Logger.getLogger(HangarStatusServiceImpl.class);

@Transactional
public void addHangar(Hangar h) {
	log.info("inside service add hangar");
	hangarDao.addHangar(h);
}
@Transactional
public void updateHangar(Hangar h) {
	log.info("inside service update hanger");
	   hangarDao.updateHangar(h);
       
}

@Transactional
public List<Hangar> listHangar()
{
	   List<Hangar> l=hangarDao.listHangar();
	   return l;
}

@Transactional
public Hangar getHangarById(Integer hid)
{
	   Hangar h=hangarDao.getHangarById(hid);
	   return h;
}

}
