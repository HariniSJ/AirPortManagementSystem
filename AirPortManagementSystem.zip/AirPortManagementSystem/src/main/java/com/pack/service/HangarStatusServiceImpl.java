package com.pack.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import com.pack.form.Hangar;
import com.pack.form.HangarStatus;
import com.pack.form.Planes;
import com.pack.dao.HangarStatusDao;

public class HangarStatusServiceImpl implements HangarStatusService {

	Logger log = Logger.getLogger(HangarStatusServiceImpl.class);
	
	public HangarStatusDao hangarStatusDao;
	
	public void setHangarStatusDao(HangarStatusDao hangarStatusDao) {
		this.hangarStatusDao = hangarStatusDao;
	}

	@Transactional
	public	List<Hangar>  fetchHangars() {
		log.info("Inside service fetchHangars");
		List l = hangarStatusDao.fetchHangars();
		return l;
	}
	
	@Transactional
	public	List<HangarStatus>  fetchHangarStatus() {
		log.info("Inside service fetchHangarstatus");
		List l = hangarStatusDao.fetchHangarStatus();
		return l;
	}
	
	@Transactional
	public	List<Planes>  fetchPlanes() {
		log.info("Inside service fetchPlanes");
		List l = hangarStatusDao.fetchPlanes();
		return l;
	}


	@Transactional
	public	List<HangarStatus>  getAllotedHangars() {
		log.info("Inside service getAllotedHangars");
		List l = hangarStatusDao.getAllotedHangars();
		return l;
	}

	@Transactional
	public void updateHangars(HangarStatus hangarStatus) {
		log.info("Inside service updateHangars");
		hangarStatusDao.updateHangars(hangarStatus);
	}

	@Transactional
	public void unassignHangars(HangarStatus hangarStatus) {

		log.info("Inside service unassignHangars");
		hangarStatusDao.unassignHangars(hangarStatus);
	}

	@Transactional
	public int updateHangarStatus(int hId) {
		log.info("Inside service updateHangarStatus");
		int i = hangarStatusDao.updateHangarStatus(hId);
		return i;
	}

	@Transactional
	public int unassignHangarStatus(int hId) {
		log.info("Inside service unassignHangarStatus");
		int i = hangarStatusDao.unassignHangarStatus(hId);
		return i;
	}
	
	@Transactional
	public int updatePlaneStatus(int pId) {
		log.info("Inside service updatePlaneStatus");
		int i = hangarStatusDao.updatePlaneStatus(pId);
		return i;
	}


	@Transactional
	public int unassignPlaneStatus(int pId) {
		log.info("Inside service unassignPlaneStatus");
		int i = hangarStatusDao.unassignPlaneStatus(pId);
		return i;
	}
	
	@Transactional
	public HangarStatus getHangarStatusById(int id) {
		log.info("Inside service unassignPlaneStatus");
		HangarStatus hs=hangarStatusDao.getHangarStatusById(id);
		return hs;
	}


	
}
