package com.pack.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.dao.PlanesDao;

import com.pack.form.Planes;



@Service
public class PlanesServiceImpl implements PlanesService{

	 private PlanesDao planesDao;
	 public void setPlanesDao(PlanesDao planesDao) {
			this.planesDao = planesDao;
		}
   
	private static Logger log=Logger.getLogger(PlanesServiceImpl.class);
   
	@Transactional
    public void addPlanes(Planes p) {
		log.info("inside service add planes");
		planesDao.addPlanes(p);
           
    }
	
    @Transactional
    public void updatePlanes(Planes p) {
 	   planesDao.updatePlanes(p);
           
    }
    
    @Transactional
    public List<Planes> listPlanes()
    {
 	   List<Planes> l=planesDao.listPlanes();
 	   return l;
    }
    
    @Transactional
    public Planes getPlanesById(Integer pid)
    {
 	   Planes p=planesDao.getPlanesById(pid);
 	   return p;
    }
}
