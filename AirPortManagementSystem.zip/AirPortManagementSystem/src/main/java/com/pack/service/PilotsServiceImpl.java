package com.pack.service;

import java.util.List;



import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.dao.PilotsDao;
import com.pack.form.Pilots;

@Service
public class PilotsServiceImpl implements PilotsService{

	 private PilotsDao pilotsDao;
	 public void setPilotsDao(PilotsDao pilotsDao) {
			this.pilotsDao = pilotsDao;
		}
   
	private static Logger log=Logger.getLogger(PilotsServiceImpl.class);
   
	@Transactional
    public void addPilots(Pilots p) {
		log.info("inside service add pilots");
		pilotsDao.addPilots(p);
           
    }
  
	@Transactional
    public void updatePilots(Pilots p) {
 	   pilotsDao.updatePilots(p);
           
    }
	
    @Transactional
    public List<Pilots> listPilots()
    {
 	   List<Pilots> l=pilotsDao.listPilots();
 	   return l;
    }
    
    @Transactional
    public Pilots getPilotsById(Integer pid)
    {
 	   Pilots p=pilotsDao.getPilotsById(pid);
 	   return p;
    }
}
