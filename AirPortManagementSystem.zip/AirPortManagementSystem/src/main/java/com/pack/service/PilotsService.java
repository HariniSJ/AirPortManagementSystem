package com.pack.service;

import java.util.List;

import com.pack.form.Pilots;

public interface PilotsService {

	public void addPilots(Pilots p);

	public void updatePilots(Pilots p);

	public List<Pilots> listPilots();

	public Pilots getPilotsById(Integer pid);
}
