package com.pack.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.dao.AirportDao;
import com.pack.form.RegisterManager;

@Service
public class AirportServiceImpl implements AirportService{
	private AirportDao airportDao;
	public void setAirportDao(AirportDao airportDao) {
        this.airportDao = airportDao;
}

@Transactional
public void addManager(RegisterManager m)
{
	airportDao.addManager(m);
	
}

@Transactional
public Boolean validateManager(String managerId, String password) {
	
	Boolean isValid=airportDao.validateManager(managerId, password);
	return isValid;
}

@Transactional
public List<RegisterManager> listManager() {
	List<RegisterManager> l=airportDao.listManager();
    return l;

}

@Transactional
public void updateManager(String managerId,Integer status) {
	airportDao.updateManager(managerId,status);
	
}

@Transactional
public void deleteManager(String managerId) {
	airportDao.deleteManager(managerId);
}


@Transactional
public String getManagerName(String managerId) {
String name=airportDao.getManagerName(managerId);
	return name;
}

}

