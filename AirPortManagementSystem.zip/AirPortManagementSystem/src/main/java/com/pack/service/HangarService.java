package com.pack.service;

import java.util.List;

import com.pack.form.Hangar;

public interface HangarService {
	public void addHangar(Hangar h);

	public void updateHangar(Hangar h);

	public List<Hangar> listHangar();

	public Hangar getHangarById(Integer hid);
}
