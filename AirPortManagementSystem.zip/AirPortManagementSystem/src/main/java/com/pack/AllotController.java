package com.pack;

import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.form.HangarStatus;
import com.pack.service.HangarStatusService;
import com.pack.service.PlanesService;

@Controller
public class AllotController {

	Logger log = Logger.getLogger(AllotController.class);

	@Autowired(required = true)
	@Qualifier(value = "hangarStatusService")
	private HangarStatusService hangarStatusService;

	@Autowired(required = true)
	@Qualifier(value = "planesService")
	private PlanesService planesService;

	public void setHangarStatusService(HangarStatusService hangarStatusService) {
		this.hangarStatusService = hangarStatusService;
	}

	public void setPlanesService(PlanesService planesService) {
		this.planesService = planesService;
	}

	@RequestMapping(value = "/manager", method = RequestMethod.GET)
	public String Manager(HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			return "Manager";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/viewAllotedHangar")
	public String viewAllotedHangar(Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			model.addAttribute("allotedHangarList", hangarStatusService.getAllotedHangars());
			return "ViewAllotedHangar";
		} else {
			return "welcomepage";
		}
	}

	@RequestMapping(value = "/dispAllotHangar")
	public String goToAllotHangar(Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			log.info("Inside display List");
			List l = hangarStatusService.fetchHangars();
			System.out.println(l);
			model.addAttribute("availableHangarList", hangarStatusService.fetchHangars());
			model.addAttribute("planesList", hangarStatusService.fetchPlanes());
			return "Sample";
		} else
			return "welcomepage";
	}

	@RequestMapping(value = "/allotHangar")
	public String fetchHangarStatus(Model model, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			log.info("Inside allot hangar");
			List l = hangarStatusService.fetchHangars();
			model.addAttribute("availableHangarList", l);
			model.addAttribute("planesList", hangarStatusService.fetchPlanes());
			model.addAttribute("hangarstatus", new HangarStatus());
			return "UpdateHangarStatus";
		} else
			return "welcomepage";
	}

	@RequestMapping(value = "/updateHangarStatus")
	public String updateHangarStatus(@ModelAttribute("hangarstatus") @Validated HangarStatus hangarstatus,
			BindingResult bindingResult, Model model, Map<String, Object> map) {
		log.info("Inside update hangar");
		if (bindingResult.hasErrors()) {
			System.out.println("Hi");
			return "UpdateHangarStatus";
		} else {
			map.put("hangarstatus", new HangarStatus());
			Random random = new Random();
			int num = random.nextInt(90000) + 1000;
			hangarstatus.setId(num);
			hangarStatusService.updateHangars(hangarstatus);
			int hId = hangarstatus.getHangarId();
			int pId = hangarstatus.getPlaneid();
			hangarStatusService.updateHangarStatus(hId);
			hangarStatusService.updatePlaneStatus(pId);
			return "Manager";
		}
	}

	@RequestMapping(value = "/unassignHangar", method = RequestMethod.GET)
	public String Update(Map<String, Object> map, Model model,
			@ModelAttribute("hangarStatus") @Validated HangarStatus hangarStatus, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			log.info("INSIDE UPDATE");
			map.put("hangarStatus", new HangarStatus());

			model.addAttribute("hangarStatusList", hangarStatusService.fetchHangarStatus());
			return "UnassignHangar";
		} else
			return "welcomepage";
	}

	@RequestMapping(value = "/unassign")
	public String unassign(@ModelAttribute("hangarStatus") @Validated HangarStatus hangarStatus,
			BindingResult bindingResult, Model model, Map<String, Object> map, HttpSession session) {
		if ((session.getAttribute("username")) != null) {

			log.info("Inside unassign hangar");

			hangarStatusService.unassignHangars(hangarStatus);

			int hId = hangarStatus.getHangarId();
			int pId = hangarStatus.getPlaneid();
			hangarStatusService.unassignHangarStatus(hId);
			hangarStatusService.unassignPlaneStatus(pId);
			model.addAttribute("hangarStatusList", hangarStatusService.fetchHangarStatus());
			return "Manager";
		} else
			return "welcomepage";
	}

	@RequestMapping(value = "/unassign/{id}")
	public String un(Map<String, Object> map, @PathVariable("id") Integer id,
			@ModelAttribute("hangarStatus") @Validated HangarStatus hangarStatus, HttpSession session) {
		if ((session.getAttribute("username")) != null) {
			log.info("Going to get id");
			map.put("hangarStatus", hangarStatusService.getHangarStatusById(id));
			log.info("Got detail");
			map.put("hangarStatusList", hangarStatusService.fetchHangarStatus());
			return "UnassignHangar";
		} else
			return "welcomepage";
	}

}
