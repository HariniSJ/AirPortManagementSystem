package com.pack.form;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="ManagerRegister",schema="airport")
public class RegisterManager {
@Id
private String managerId;
private Integer status;
@NotEmpty
@Size(max=50)
@Pattern(regexp="[^0-9]*")

private String firstName;

@NotEmpty
@Size(max=50)	
@Pattern(regexp="[^0-9]*")
private String lastName;
@NotNull
@Max(99)private Integer age;
@NotEmpty
private String gender;
@Size(max=10)
private String dob;
@NotEmpty
@Phone
private String contactNo;
@Phone
private String altContactNo;
@Size(max=50)
@Email
private String emailId;

@NotEmpty
@Size(max=15)
private String password;
public Integer getStatus() {
	return status;
}
public void setStatus(Integer status) {
	this.status = status;
}
public String getManagerId() {
	return managerId;
}
public void setManagerId(String managerId) {
	this.managerId = managerId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Integer getAge() {
	return age;
}
public void setAge(Integer age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getContactNo() {
	return contactNo;
}
public void setContactNo(String contactNo) {
	this.contactNo = contactNo;
}
public String getAltContactNo() {
	return altContactNo;
}
public void setAltContactNo(String altContactNo) {
	this.altContactNo = altContactNo;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}
