package com.pack.form;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "PILOTS",schema="airport")
public class Pilots {
	@Id
	private Integer pilotid;
	@NotEmpty
	@Size(min=2,max=100)
	@Pattern(regexp="[^0-9]*")
	private String licenseNumber;
	
	@NotEmpty
	@Size(min=2,max=100)
	private String addressLine1;
	
	@NotEmpty
	@Size(min=2,max=100)
	@Pattern(regexp="[^0-9]*")
	private String addressLine2;
	
    @NotEmpty
    @Size(min=2,max=50)
    @Pattern(regexp="[^0-9]*")
	private String city;
    
    @NotEmpty
    @Size(min=2,max=50)
    @Pattern(regexp="[^0-9]*")
	private String state;
    @NotEmpty
    @Size(min=1,max=10)
    @Pattern(regexp="[0-9]*")
	private String zipCode;
    
    @NotEmpty  
    @Size(min=9,max=9)
    @Pattern(regexp="[0-9]*")
	private String ssn;
    
	public Integer getPilotid() {
		return pilotid; 
	}
	public void setPilotid(Integer pilotid) {
		this.pilotid = pilotid;
	}
	public String getLicenseNumber() {
		return licenseNumber;
	}
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public Pilots(Integer pilotid, String licenseNumber, String addressLine1, String addressLine2, String city,
			String state, String zipCode, String ssn) {
		this.pilotid = pilotid;
		this.licenseNumber = licenseNumber;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.ssn = ssn;
	}
	public Pilots(){
	}
	}
	

