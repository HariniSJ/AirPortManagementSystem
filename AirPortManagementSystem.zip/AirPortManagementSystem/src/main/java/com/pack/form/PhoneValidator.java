package com.pack.form;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PhoneValidator implements ConstraintValidator<Phone, String>{

	@Override
	public void initialize(Phone arg0) {
	
		
	}

	@Override
	public boolean isValid(String contactno, ConstraintValidatorContext arg1) {
		if(contactno==null)
		{
			return false;
		}
		if(contactno.matches("\\d{10}")) return true;
		else return false;
	}
               
}
