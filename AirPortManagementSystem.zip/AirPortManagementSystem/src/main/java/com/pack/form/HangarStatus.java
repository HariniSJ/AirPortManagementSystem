package com.pack.form;

import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="HangarStatus")
public class HangarStatus {
	@Id
	private Integer id;

	private Integer hangarId;
	
	private Integer planeid;
	
	private String status;

	private String occFromDate;
	
	private String occTillDate;
	
	private String avlFromDate;
	

	private String avlTillDate;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getHangarId() {
		return hangarId;
	}
	public void setHangarId(Integer hangarId) {
		this.hangarId = hangarId;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getOccFromDate() {
		return occFromDate;
	}
	public void setOccFromDate(String occFromDate) {
		this.occFromDate = occFromDate;
	}
	public String getOccTillDate() {
		return occTillDate;
	}
	public void setOccTillDate(String occTillDate) {
		this.occTillDate = occTillDate;
	}
	public String getAvlFromDate() {
		return avlFromDate;
	}
	public void setAvlFromDate(String avlFromDate) {
		this.avlFromDate = avlFromDate;
	}
	
	public Integer getPlaneid() {
		return planeid;
	}
	public void setPlaneid(Integer planeid) {
		this.planeid = planeid;
	}
	public String getAvlTillDate() {
		return avlTillDate;
	}
	public void setAvlTillDate(String avlTillDate) {
		this.avlTillDate = avlTillDate;
	}
	public HangarStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HangarStatus(Integer id, Integer hangarId, Integer planeid, String status, String occFromDate,
			String occTillDate, String avlFromDate, String avlTillDate) {
		super();
		this.id = id;
		this.hangarId = hangarId;
		this.planeid = planeid;
		this.status = status;
		this.occFromDate = occFromDate;
		this.occTillDate = occTillDate;
		this.avlFromDate = avlFromDate;
		this.avlTillDate = avlTillDate;
	}
	
	
}




