package com.pack.form;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name = "PLANES",schema="airport")
public class Planes {
	@Id	
	private Integer planeid;
	private Integer ownerid;

	@NotEmpty
	@Size(min=2,max=100)
	@Pattern(regexp="[^0-9]*")
	private String ownerFirstName;

	@NotEmpty
	@Size(min=2,max=100)
	@Pattern(regexp="[^0-9]*")
	private String ownerLastName;
	

	@Phone
	private String contactno;

	@NotEmpty 
	@Email
	@Size(min=2,max=50)
	private String email;

	@NotEmpty
	@Size(min=1,max=10)
	private String planeType;
	@NotNull @Min(1) @Max(999)
	
	private Integer planeCapacity;

	private String planestatus;

public Integer getPlaneid() {
	return planeid;
}
public void setPlaneid(Integer planeid) {
	this.planeid = planeid;
}
public Integer getOwnerid() {
	return ownerid;
}
public void setOwnerid(Integer ownerid) {
	this.ownerid = ownerid;
}
public String getOwnerFirstName() {
	return ownerFirstName;
}
public void setOwnerFirstName(String ownerFirstName) {
	this.ownerFirstName = ownerFirstName;
}
public String getOwnerLastName() {
	return ownerLastName;
}
public void setOwnerLastName(String ownerLastName) {
	this.ownerLastName = ownerLastName;
}
public String getContactno() {
	return contactno;
}
public void setContactno(String contactno) {
	this.contactno = contactno;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPlaneType() {
	return planeType;
}
public void setPlaneType(String planeType) {
	this.planeType = planeType;
}
public Integer getPlaneCapacity() {
	return planeCapacity;
}
public void setPlaneCapacity(Integer planeCapacity) {
	this.planeCapacity = planeCapacity;
}
public String getPlanestatus() {
	return planestatus;
}
public void setPlanestatus(String planestatus) {
	this.planestatus = planestatus;
}

public Planes(Integer planeid,String contactno,  String email,String ownerFirstName, String ownerLastName, Integer ownerid,
		Integer planeCapacity, String planeType,String planestatus) {
	super();
	this.planeid = planeid;
	this.ownerid = ownerid;
	this.ownerFirstName = ownerFirstName;
	this.ownerLastName = ownerLastName;
	this.contactno = contactno;
	this.email = email;
	this.planeType = planeType;
	this.planeCapacity = planeCapacity;
	this.planestatus=planestatus;
}

public Planes()
{
	
}

}







