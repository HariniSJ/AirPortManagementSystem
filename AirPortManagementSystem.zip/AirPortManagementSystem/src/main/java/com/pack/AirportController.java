package com.pack;

import java.util.Map;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.pack.form.RegisterManager;
import com.pack.service.AirportService;

@Controller
@Configuration

public class AirportController 
{
	 	@Autowired
	    @Qualifier(value="airportService")
	    private AirportService airportService;
	    public void setAirportService(AirportService airportService) 
	    {
	        this.airportService = airportService;
	    }

		
	@RequestMapping("/welcome")
	public ModelAndView welcome()
	{
		ModelAndView m=new ModelAndView("welcomepage");
		return m;
	}

	@RequestMapping("/registerManager")
	public ModelAndView register()
	{
		ModelAndView m=new ModelAndView("registerManager");
		return m;
	}
	
	@RequestMapping("/databaseRegistrationManager")
	public ModelAndView login2(@Valid @ModelAttribute("registermanager") RegisterManager registermanager,BindingResult result,Map<String,Object> map)
	{
		if(result.hasErrors())
	    {
	                    ModelAndView m=new ModelAndView("registerManager");
	                    return m;
	                    
	    }
		else
	    if(null==registermanager.getManagerId())
	    {
	                    Random rand=new Random();
	                    int num=rand.nextInt(9000000)+1000000;
	                    String a=Integer.toString(num);
	                    registermanager.setManagerId(a);
	                    registermanager.setStatus(0);
	                    airportService.addManager(registermanager);
	    }
		ModelAndView m=new ModelAndView("successRegistrationM");
		return m;
	}

	@RequestMapping("/successManager")
	public ModelAndView login(@RequestParam("managerId") String managerId,@RequestParam("password") String password,HttpServletRequest request,
			HttpServletResponse response)
	{
		Boolean isValid=airportService.validateManager(managerId,password);
		if(isValid)
		{	
		ModelAndView m=new ModelAndView("Manager");
		HttpSession session = request.getSession();
		String name=airportService.getManagerName(managerId);
		
		session.setAttribute("username",name);
		session.setAttribute("password", password);
		return m;
		}
		else
		{
			ModelAndView m=new ModelAndView("welcomepage");
			m.addObject("message1","Invalid username and password");
			return m;
		}
		
	}
	
	@RequestMapping("/successAdmin")
	public ModelAndView login1(@RequestParam("adminId") String adminId,@RequestParam("password") String password, HttpServletRequest request,
			HttpServletResponse response)
	{
		
		if(adminId.equals("admin") && password.equals("adminxyz"))
		{
		ModelAndView m=new ModelAndView("successAdmin");
		HttpSession session = request.getSession();
		session.setAttribute("username", adminId);
		session.setAttribute("password", password);
		return m;
		}
		else
		{
			ModelAndView m=new ModelAndView("welcomepage");
			m.addObject("message", "Invalid username or password");
			return m;
		}
	}
	
	@RequestMapping("/viewManager")
	public ModelAndView viewManager(Map<String,Object> map,HttpSession session)
	{
		if((session.getAttribute("username"))!=null) 
		{
			ModelAndView m=new ModelAndView("viewManager");
			map.put("manager", new RegisterManager());
			m.addObject("ManagerList", airportService.listManager());
			return m;
		}
		else
		{
			ModelAndView m=new ModelAndView("welcomepage");
			return m;
		}
	}
	
	@RequestMapping("/confirm/{managerId}")
	public ModelAndView confirm(@PathVariable("managerId") String managerId,Map<String,Object> map,HttpSession session)
	{
		if((session.getAttribute("username"))!=null) 
		{
			Integer status=new Integer(1);
			airportService.updateManager(managerId,status);
			ModelAndView m=new ModelAndView("viewManager");
			map.put("manager", new RegisterManager());
			m.addObject("ManagerList", airportService.listManager());
			return m;
		}
		else
		{
			ModelAndView m=new ModelAndView("welcomepage");
			return m;
		}
	}
	
	@RequestMapping("/decline/{managerId}")
	public ModelAndView decline(@PathVariable("managerId") String managerId,Map<String,Object> map,HttpSession session)
	{
		if((session.getAttribute("username"))!=null)
		{
			airportService.deleteManager(managerId);
			ModelAndView m=new ModelAndView("viewManager");
			map.put("manager", new RegisterManager());
			m.addObject("ManagerList", airportService.listManager());
			return m;
		}
		else
		{
		ModelAndView m=new ModelAndView("welcomepage");
		return m;
		}
		
	}

	@RequestMapping(value = "/logout")
	public ModelAndView logout(HttpServletRequest request)
	{
		ModelAndView mav;
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("username");
		session.invalidate();
		mav=new ModelAndView("welcomepage");
		return mav;
	}

}












